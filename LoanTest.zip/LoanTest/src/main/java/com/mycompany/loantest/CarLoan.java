/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loantest;

/**
 *
 * @author Aldo Mwiine VU-BCS-2311-0724-EVE
 */

public class CarLoan extends Loan {
    private String car_lien;

    // No-arg constructor
    public CarLoan() {
        this.amount = 0;
        this.loan_id = "";
        this.cust_name = "";
        this.loan_type = "Car Loan";
    }

    // Assign and return car lien
    public void setCarLien(String car_lien) {
        this.car_lien = car_lien;
    }

    public String getCarLien() {
        return car_lien;
    }

    // Implement abstract method
    @Override
    public String getLoanType() {
        return loan_type;
    }
}
