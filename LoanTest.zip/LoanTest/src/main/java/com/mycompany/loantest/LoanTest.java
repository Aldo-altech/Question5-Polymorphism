/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loantest;

/**
 *
 * @author Aldo Mwiine VU-BCS-2311-0724-EVE
 */


public class LoanTest {

    public static void main(String[] args) {
        // Create CarLoan objects
        CarLoan carLoan1 = new CarLoan();
        CarLoan carLoan2 = new CarLoan();

        // Assign values
        carLoan1.setLoanId("CL001");
        carLoan1.setCustName("Aldo Mwiine");
        carLoan1.setAmount(15000);
        carLoan1.setCarLien("Toyota Corolla 2020");

        carLoan2.setLoanId("CL002");
        carLoan2.setCustName("James Mos");
        carLoan2.setAmount(22000);
        carLoan2.setCarLien("Honda Civic 2022");

        // Display all values
        System.out.println("----- CAR LOAN DETAILS -----");
        System.out.println("Loan ID: " + carLoan1.getLoanId());
        System.out.println("Customer Name: " + carLoan1.getCustName());
        System.out.println("Loan Type: " + carLoan1.getLoanType());
        System.out.println("Amount: " + carLoan1.getAmount());
        System.out.println("Car Lien: " + carLoan1.getCarLien());
        System.out.println();

        System.out.println("Loan ID: " + carLoan2.getLoanId());
        System.out.println("Customer Name: " + carLoan2.getCustName());
        System.out.println("Loan Type: " + carLoan2.getLoanType());
        System.out.println("Amount: " + carLoan2.getAmount());
        System.out.println("Car Lien: " + carLoan2.getCarLien());
    }
}
