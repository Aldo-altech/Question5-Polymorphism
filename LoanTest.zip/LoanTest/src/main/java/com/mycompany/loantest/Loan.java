/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loantest;

/**
 *
 * @author Aldo Mwiine VU-BCS-2311-0724-EVE
 */

public abstract class Loan {
    protected String loan_id;
    protected String loan_type;
    protected double amount;
    protected String cust_name;

    // Default constructor
    public Loan() {
        amount = 0;
    }

    // Set methods
    public void setLoanId(String loan_id) {
        this.loan_id = loan_id;
    }

    public void setCustName(String cust_name) {
        this.cust_name = cust_name;
    }

    // Get methods
    public String getLoanId() {
        return loan_id;
    }

    public String getCustName() {
        return cust_name;
    }

    // Set and get for amount
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    // Abstract method for loan type
    public abstract String getLoanType();
}
